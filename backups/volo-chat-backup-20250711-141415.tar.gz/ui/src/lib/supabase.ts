// Temporary mock implementation until @supabase/supabase-js is installed
// TODO: Replace with real Supabase client
export * from './supabase-mock'; 