import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Switch } from '../components/ui/switch';
import { Label } from '../components/ui/label';
import { Separator } from '../components/ui/separator';
import { Badge } from '../components/ui/badge';
import { KeyboardShortcutsHelp } from '@/components/keyboard-shortcuts-help';
import { toast } from 'sonner';
import { 
  Moon, 
  Sun, 
  Monitor, 
  Bell, 
  Keyboard, 
  Palette,
  Shield,
  Database,
  HelpCircle,
  RefreshCw,
  Sparkles,
  Zap
} from 'lucide-react';

export function Settings() {
  const [demoMode, setDemoMode] = useState(localStorage.getItem('demoMode') === 'true');
  const [notifications, setNotifications] = useState(true);
  const [autoRefresh, setAutoRefresh] = useState(true);
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [theme, setTheme] = useState('system');
  const [language, setLanguage] = useState('el');
  const [showShortcuts, setShowShortcuts] = useState(false);

  const handleDemoModeToggle = () => {
    const newValue = !demoMode;
    setDemoMode(newValue);
    localStorage.setItem('demoMode', newValue.toString());
    // Reload page to apply changes
    window.location.reload();
  };

  const handleLanguageChange = (newLanguage: string) => {
    setLanguage(newLanguage);
  };

  // Load demo mode from localStorage on component mount
  useEffect(() => {
    const savedDemoMode = localStorage.getItem('demoMode');
    if (savedDemoMode !== null) {
      setDemoMode(savedDemoMode === 'true');
    }
  }, []);

  const settingsSections = [
    {
      title: 'Γενικές Ρυθμίσεις',
      icon: <Database className="w-5 h-5" />,
      color: 'from-blue-500 to-blue-600',
      items: [
        {
          title: 'Demo Mode',
          description: 'Εμφάνιση προσομοιωμένων δεδομένων για παρουσιάσεις',
          type: 'switch',
          value: demoMode,
          onChange: handleDemoModeToggle,
          badge: 'Επαναφόρτωση'
        },
        {
          title: 'Αυτόματη Ενημέρωση',
          description: 'Αυτόματη ενημέρωση δεδομένων κάθε 5 λεπτά',
          type: 'switch',
          value: autoRefresh,
          onChange: setAutoRefresh
        }
      ]
    },
    {
      title: 'Εμφάνιση',
      icon: <Palette className="w-5 h-5" />,
      color: 'from-purple-500 to-purple-600',
      items: [
        {
          title: 'Θέμα',
          description: 'Επιλέξτε το θέμα της εφαρμογής',
          type: 'theme',
          value: theme,
          onChange: setTheme
        },
        {
          title: 'Γλώσσα',
          description: 'Επιλέξτε τη γλώσσα της εφαρμογής',
          type: 'language',
          value: language,
          onChange: handleLanguageChange
        }
      ]
    },
    {
      title: 'Ειδοποιήσεις',
      icon: <Bell className="w-5 h-5" />,
      color: 'from-green-500 to-green-600',
      items: [
        {
          title: 'Ειδοποιήσεις',
          description: 'Λήψη ειδοποιήσεων για σημαντικά γεγονότα',
          type: 'switch',
          value: notifications,
          onChange: setNotifications
        }
      ]
    },
    {
      title: 'Προχωρημένες Ρυθμίσεις',
      icon: <Zap className="w-5 h-5" />,
      color: 'from-orange-500 to-orange-600',
      items: [
        {
          title: 'Εμφάνιση Προχωρημένων',
          description: 'Εμφάνιση προχωρημένων επιλογών ρυθμίσεων',
          type: 'switch',
          value: showAdvanced,
          onChange: setShowAdvanced
        }
      ]
    }
  ];

  const renderSettingItem = (item: any) => {
    switch (item.type) {
      case 'switch':
        return (
          <div className="flex items-center justify-between p-4 hover:bg-white/50 dark:hover:bg-gray-800/50 rounded-2xl transition-all duration-300 border border-transparent hover:border-gray-200/50 dark:hover:border-gray-700/50">
            <div className="flex items-center gap-4">
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-1">
                  <Label className="text-sm font-semibold text-gray-900 dark:text-gray-100">
                    {item.title}
                  </Label>
                  {item.badge && (
                    <Badge variant="outline" className="text-xs bg-yellow-50 text-yellow-700 border-yellow-200 dark:bg-yellow-900/20 dark:text-yellow-300 dark:border-yellow-800">
                      {item.badge}
                    </Badge>
                  )}
                </div>
                <p className="text-sm text-gray-600 dark:text-gray-300">{item.description}</p>
              </div>
            </div>
            <Switch
              checked={item.value}
              onCheckedChange={item.onChange}
              className="data-[state=checked]:bg-gradient-to-r data-[state=checked]:from-blue-500 data-[state=checked]:to-purple-500"
            />
          </div>
        );

      case 'theme':
        return (
          <div className="p-4 hover:bg-white/50 dark:hover:bg-gray-800/50 rounded-2xl transition-all duration-300 border border-transparent hover:border-gray-200/50 dark:hover:border-gray-700/50">
            <div className="flex items-center gap-4 mb-3">
              <Label className="text-sm font-semibold text-gray-900 dark:text-gray-100">
                {item.title}
              </Label>
            </div>
            <p className="text-sm text-gray-600 dark:text-gray-300 mb-4">{item.description}</p>
            <div className="flex gap-3">
              {[
                { value: 'light', icon: Sun, label: 'Φωτεινό' },
                { value: 'dark', icon: Moon, label: 'Σκοτεινό' },
                { value: 'system', icon: Monitor, label: 'Σύστημα' }
              ].map((themeOption) => {
                const Icon = themeOption.icon;
                return (
                  <Button
                    key={themeOption.value}
                    variant={item.value === themeOption.value ? "default" : "outline"}
                    size="sm"
                    onClick={() => item.onChange(themeOption.value)}
                    className={`flex items-center gap-2 px-4 py-2 rounded-xl transition-all duration-300 ${
                      item.value === themeOption.value
                        ? 'bg-gradient-to-r from-blue-600 to-purple-600 text-white shadow-lg shadow-blue-500/25'
                        : 'bg-white/50 dark:bg-gray-900/50 backdrop-blur-xl border-gray-200/50 dark:border-gray-700/50 hover:bg-white/70 dark:hover:bg-gray-900/70'
                    }`}
                  >
                    <Icon className="w-4 h-4" />
                    {themeOption.label}
                  </Button>
                );
              })}
            </div>
          </div>
        );

      case 'language':
        return (
          <div className="p-4 hover:bg-white/50 dark:hover:bg-gray-800/50 rounded-2xl transition-all duration-300 border border-transparent hover:border-gray-200/50 dark:hover:border-gray-700/50">
            <div className="flex items-center gap-4 mb-3">
              <Label className="text-sm font-semibold text-gray-900 dark:text-gray-100">
                {item.title}
              </Label>
            </div>
            <p className="text-sm text-gray-600 dark:text-gray-300 mb-4">{item.description}</p>
            <div className="flex gap-3">
              {[
                { value: 'el', label: 'Ελληνικά', flag: '🇬🇷' },
                { value: 'en', label: 'English', flag: '🇺🇸' }
              ].map((langOption) => (
                <Button
                  key={langOption.value}
                  variant={item.value === langOption.value ? "default" : "outline"}
                  size="sm"
                  onClick={() => item.onChange(langOption.value)}
                  className={`flex items-center gap-2 px-4 py-2 rounded-xl transition-all duration-300 ${
                    item.value === langOption.value
                      ? 'bg-gradient-to-r from-blue-600 to-purple-600 text-white shadow-lg shadow-blue-500/25'
                      : 'bg-white/50 dark:bg-gray-900/50 backdrop-blur-xl border-gray-200/50 dark:border-gray-700/50 hover:bg-white/70 dark:hover:bg-gray-900/70'
                  }`}
                >
                  <span className="text-lg">{langOption.flag}</span>
                  {langOption.label}
                </Button>
              ))}
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 via-white to-blue-50/30 dark:from-gray-950 dark:via-gray-900 dark:to-blue-950/20">
      <div className="container mx-auto px-4 py-8 space-y-8">
        {/* Header */}
        <div className="space-y-4">
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <span>Dashboard</span>
            <span>/</span>
            <span className="text-foreground">Ρυθμίσεις</span>
          </div>
          
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div className="space-y-2">
              <div className="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-blue-50 to-purple-50 dark:from-blue-950/20 dark:to-purple-950/20 rounded-full border border-blue-200/50 dark:border-blue-800/30">
                <Database className="w-4 h-4 text-blue-600 dark:text-blue-400" />
                <span className="text-sm font-medium text-blue-700 dark:text-blue-300">Ρυθμίσεις Εφαρμογής</span>
              </div>
              <h1 className="text-4xl font-bold bg-gradient-to-r from-gray-900 to-gray-600 dark:from-white dark:to-gray-300 bg-clip-text text-transparent">
                Ρυθμίσεις
              </h1>
              <p className="text-lg text-muted-foreground">
                Προσαρμόστε την εφαρμογή στις ανάγκες σας
              </p>
            </div>
            
            <div className="flex gap-3">
              <Button 
                onClick={() => window.location.reload()}
                className="bg-gradient-to-r from-blue-600 to-purple-600 text-white hover:from-blue-700 hover:to-purple-700 shadow-lg shadow-blue-500/25 rounded-2xl px-6 py-3 transition-all duration-300 hover:scale-105"
              >
                <RefreshCw className="w-4 h-4 mr-2" />
                Εφαρμογή Αλλαγών
              </Button>
            </div>
          </div>
        </div>

        {/* Settings Sections */}
        <div className="grid gap-8 lg:grid-cols-2">
          {settingsSections.map((section, index) => (
            <Card key={index} className="border-0 bg-white/50 dark:bg-gray-900/50 backdrop-blur-xl rounded-3xl shadow-xl shadow-gray-500/10">
              <CardHeader className="pb-6">
                <CardTitle className="flex items-center gap-3 text-2xl">
                  <div className={`p-2 bg-gradient-to-br ${section.color} rounded-xl shadow-lg`}>
                    {section.icon}
                  </div>
                  {section.title}
                </CardTitle>
                <CardDescription className="text-base">
                  Διαχείριση {section.title.toLowerCase()}
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {section.items.map((item, itemIndex) => (
                  <div key={itemIndex}>
                    {renderSettingItem(item)}
                    {itemIndex < section.items.length - 1 && (
                      <Separator className="my-4 bg-gradient-to-r from-transparent via-gray-200 dark:via-gray-700 to-transparent" />
                    )}
                  </div>
                ))}
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Quick Actions */}
        <Card className="border-0 bg-gradient-to-br from-blue-50/50 to-purple-50/50 dark:from-blue-950/20 dark:to-purple-950/20 backdrop-blur-xl rounded-3xl shadow-xl shadow-blue-500/10">
          <CardHeader className="text-center pb-6">
            <CardTitle className="flex items-center justify-center gap-3 text-2xl">
              <div className="p-3 bg-gradient-to-br from-blue-500 to-purple-500 rounded-2xl shadow-lg">
                <Sparkles className="w-6 h-6 text-white" />
              </div>
              Γρήγορες Ενέργειες
            </CardTitle>
            <CardDescription className="text-lg">
              Χρήσιμες ενέργειες για την εφαρμογή
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4 md:grid-cols-3">
              <Button 
                onClick={() => setShowShortcuts(true)}
                className="group p-6 h-auto flex flex-col items-center gap-4 bg-white/50 dark:bg-gray-900/50 backdrop-blur-xl hover:bg-white/70 dark:hover:bg-gray-900/70 rounded-2xl border border-gray-200/50 dark:border-gray-700/50 transition-all duration-300 hover:scale-105"
              >
                <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-blue-600 rounded-2xl flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform duration-300">
                  <Keyboard className="w-8 h-8 text-white" />
                </div>
                <div className="text-center">
                  <h4 className="font-semibold text-gray-900 dark:text-gray-100 mb-2">Keyboard Shortcuts</h4>
                  <p className="text-sm text-gray-600 dark:text-gray-300">Δείτε όλα τα shortcuts</p>
                </div>
              </Button>
              
              <Button 
                onClick={() => {
                  localStorage.removeItem('onboarding-completed');
                  toast.success('Το onboarding tour θα ξεκινήσει ξανά!');
                  setTimeout(() => window.location.reload(), 1000);
                }}
                className="group p-6 h-auto flex flex-col items-center gap-4 bg-white/50 dark:bg-gray-900/50 backdrop-blur-xl hover:bg-white/70 dark:hover:bg-gray-900/70 rounded-2xl border border-gray-200/50 dark:border-gray-700/50 transition-all duration-300 hover:scale-105"
              >
                <div className="w-16 h-16 bg-gradient-to-br from-green-500 to-green-600 rounded-2xl flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform duration-300">
                  <HelpCircle className="w-8 h-8 text-white" />
                </div>
                <div className="text-center">
                  <h4 className="font-semibold text-gray-900 dark:text-gray-100 mb-2">Επανεκκίνηση Tour</h4>
                  <p className="text-sm text-gray-600 dark:text-gray-300">Ξαναδείτε το onboarding</p>
                </div>
              </Button>
              
              <Button 
                onClick={() => {
                  const settings = {
                    demoMode,
                    notifications,
                    autoRefresh,
                    theme,
                    language,
                    showAdvanced
                  };
                  const blob = new Blob([JSON.stringify(settings, null, 2)], { type: 'application/json' });
                  const url = URL.createObjectURL(blob);
                  const a = document.createElement('a');
                  a.href = url;
                  a.download = 'volo-settings.json';
                  a.click();
                  URL.revokeObjectURL(url);
                  toast.success('Οι ρυθμίσεις εξήχθησαν επιτυχώς!');
                }}
                className="group p-6 h-auto flex flex-col items-center gap-4 bg-white/50 dark:bg-gray-900/50 backdrop-blur-xl hover:bg-white/70 dark:hover:bg-gray-900/70 rounded-2xl border border-gray-200/50 dark:border-gray-700/50 transition-all duration-300 hover:scale-105"
              >
                <div className="w-16 h-16 bg-gradient-to-br from-purple-500 to-purple-600 rounded-2xl flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform duration-300">
                  <Database className="w-8 h-8 text-white" />
                </div>
                <div className="text-center">
                  <h4 className="font-semibold text-gray-900 dark:text-gray-100 mb-2">Εξαγωγή Ρυθμίσεων</h4>
                  <p className="text-sm text-gray-600 dark:text-gray-300">Αποθηκεύστε τις ρυθμίσεις</p>
                </div>
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Advanced Settings (Conditional) */}
        {showAdvanced && (
          <Card className="border-0 bg-white/50 dark:bg-gray-900/50 backdrop-blur-xl rounded-3xl shadow-xl shadow-gray-500/10">
            <CardHeader className="pb-6">
              <CardTitle className="flex items-center gap-3 text-2xl">
                <div className="p-2 bg-gradient-to-br from-red-500 to-red-600 rounded-xl shadow-lg">
                  <Shield className="w-6 h-6 text-white" />
                </div>
                Προχωρημένες Ρυθμίσεις
              </CardTitle>
              <CardDescription className="text-base">
                Προχωρημένες επιλογές για προχωρημένους χρήστες
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="p-4 bg-yellow-50 dark:bg-yellow-900/20 rounded-2xl border border-yellow-200/50 dark:border-yellow-800/30">
                <p className="text-sm text-yellow-800 dark:text-yellow-200">
                  ⚠️ Προσοχή: Οι προχωρημένες ρυθμίσεις μπορεί να επηρεάσουν την απόδοση της εφαρμογής.
                </p>
              </div>
              
              <div className="grid gap-4 md:grid-cols-2">
                <div className="p-4 hover:bg-white/50 dark:hover:bg-gray-800/50 rounded-2xl transition-all duration-300 border border-transparent hover:border-gray-200/50 dark:hover:border-gray-700/50">
                  <div className="flex items-center gap-4 mb-3">
                    <Label className="text-sm font-semibold text-gray-900 dark:text-gray-100">
                      Debug Mode
                    </Label>
                  </div>
                  <p className="text-sm text-gray-600 dark:text-gray-300 mb-4">Ενεργοποίηση debug mode για ανάπτυξη</p>
                  <Switch className="data-[state=checked]:bg-gradient-to-r data-[state=checked]:from-red-500 data-[state=checked]:to-red-600" />
                </div>
                
                <div className="p-4 hover:bg-white/50 dark:hover:bg-gray-800/50 rounded-2xl transition-all duration-300 border border-transparent hover:border-gray-200/50 dark:hover:border-gray-700/50">
                  <div className="flex items-center gap-4 mb-3">
                    <Label className="text-sm font-semibold text-gray-900 dark:text-gray-100">
                      Performance Mode
                    </Label>
                  </div>
                  <p className="text-sm text-gray-600 dark:text-gray-300 mb-4">Βελτιστοποίηση για καλύτερη απόδοση</p>
                  <Switch className="data-[state=checked]:bg-gradient-to-r data-[state=checked]:from-green-500 data-[state=checked]:to-green-600" />
                </div>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
      {showShortcuts && <KeyboardShortcutsHelp />}
    </div>
  );
} 