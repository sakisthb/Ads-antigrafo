import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Badge } from '../components/ui/badge';
import { 
  TrendingUp, 
  DollarSign, 
  Users, 
  MousePointer, 
  Eye,
  Target,
  BarChart3,
  ArrowUpRight,
  ArrowDownRight,
  Sparkles,
  Activity,
  Zap
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';

interface KPI {
  title: string;
  value: string;
  change: number;
  icon: React.ReactNode;
  color: string;
  trend: 'up' | 'down';
}

const KPIS: KPI[] = [
  {
    title: 'Συνολικό Κόστος',
    value: '€12,450',
    change: 12.5,
    icon: <DollarSign className="w-5 h-5" />,
    color: 'from-green-500 to-emerald-500',
    trend: 'up'
  },
  {
    title: 'Επισκέψεις',
    value: '45.2K',
    change: 8.2,
    icon: <Users className="w-5 h-5" />,
    color: 'from-blue-500 to-cyan-500',
    trend: 'up'
  },
  {
    title: 'CTR',
    value: '3.24%',
    change: -2.1,
    icon: <MousePointer className="w-5 h-5" />,
    color: 'from-purple-500 to-pink-500',
    trend: 'down'
  },
  {
    title: 'Impressions',
    value: '1.2M',
    change: 15.7,
    icon: <Eye className="w-5 h-5" />,
    color: 'from-orange-500 to-red-500',
    trend: 'up'
  }
];

const PERFORMANCE_DATA = [
  { name: 'Facebook', value: 45, color: 'from-blue-500 to-blue-600' },
  { name: 'Instagram', value: 30, color: 'from-purple-500 to-pink-500' },
  { name: 'Google Ads', value: 15, color: 'from-red-500 to-orange-500' },
  { name: 'TikTok', value: 10, color: 'from-black to-gray-800' }
];

const RECENT_ACTIVITY = [
  { action: 'Νέα καμπάνια δημιουργήθηκε', time: '2 ώρες πριν', type: 'campaign' },
  { action: 'Ενημέρωση budget', time: '4 ώρες πριν', type: 'budget' },
  { action: 'Νέο ad set προστέθηκε', time: '6 ώρες πριν', type: 'adset' },
  { action: 'Αλλαγή targeting', time: '1 ημέρα πριν', type: 'targeting' }
];

export function Dashboard() {
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Simulate loading
    const timer = setTimeout(() => setIsLoading(false), 1000);
    return () => clearTimeout(timer);
  }, []);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center space-y-4">
          <div className="w-16 h-16 mx-auto bg-gradient-to-br from-blue-500 to-purple-500 rounded-2xl flex items-center justify-center animate-pulse">
            <Sparkles className="w-8 h-8 text-white" />
          </div>
          <p className="text-lg text-muted-foreground">Φόρτωση Dashboard...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 via-white to-blue-50/30 dark:from-gray-950 dark:via-gray-900 dark:to-blue-950/20">
      <div className="container mx-auto px-4 py-8 space-y-8">
        {/* Header */}
        <div className="space-y-4">
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <span>Dashboard</span>
          </div>
          
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div className="space-y-2">
              <div className="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-blue-50 to-purple-50 dark:from-blue-950/20 dark:to-purple-950/20 rounded-full border border-blue-200/50 dark:border-blue-800/30">
                <Activity className="w-4 h-4 text-blue-600 dark:text-blue-400" />
                <span className="text-sm font-medium text-blue-700 dark:text-blue-300">Live Analytics</span>
              </div>
              <h1 className="text-4xl font-bold bg-gradient-to-r from-gray-900 to-gray-600 dark:from-white dark:to-gray-300 bg-clip-text text-transparent">
                Dashboard
              </h1>
              <p className="text-lg text-muted-foreground">
                Επισκόπηση της απόδοσης των καμπανιών σας
              </p>
            </div>
            
            <div className="flex gap-3">
              <Button 
                onClick={() => navigate('/campaigns')}
                className="bg-gradient-to-r from-blue-600 to-purple-600 text-white hover:from-blue-700 hover:to-purple-700 shadow-lg shadow-blue-500/25 rounded-2xl px-6 py-3 transition-all duration-300 hover:scale-105"
              >
                <Target className="w-4 h-4 mr-2" />
                Δείτε Καμπάνιες
              </Button>
              <Button 
                variant="outline"
                onClick={() => navigate('/analytics')}
                className="border-gray-200/50 dark:border-gray-700/50 bg-white/50 dark:bg-gray-900/50 backdrop-blur-xl hover:bg-white/70 dark:hover:bg-gray-900/70 rounded-2xl px-6 py-3 transition-all duration-300"
              >
                <BarChart3 className="w-4 h-4 mr-2" />
                Analytics
              </Button>
            </div>
          </div>
        </div>

        {/* KPI Cards */}
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
          {KPIS.map((kpi, index) => (
            <Card key={index} className="border-0 bg-white/50 dark:bg-gray-900/50 backdrop-blur-xl rounded-3xl shadow-xl shadow-gray-500/10 hover:shadow-2xl hover:shadow-gray-500/20 transition-all duration-300 hover:scale-105 group">
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <div className={`p-3 bg-gradient-to-br ${kpi.color} rounded-2xl shadow-lg group-hover:scale-110 transition-transform duration-300`}>
                    {kpi.icon}
                  </div>
                  <Badge 
                    variant="outline" 
                    className={`flex items-center gap-1 px-3 py-1 rounded-full text-sm font-medium ${
                      kpi.trend === 'up' 
                        ? 'bg-green-50 text-green-700 border-green-200 dark:bg-green-900/20 dark:text-green-300 dark:border-green-800' 
                        : 'bg-red-50 text-red-700 border-red-200 dark:bg-red-900/20 dark:text-red-300 dark:border-red-800'
                    }`}
                  >
                    {kpi.trend === 'up' ? (
                      <ArrowUpRight className="w-3 h-3" />
                    ) : (
                      <ArrowDownRight className="w-3 h-3" />
                    )}
                    {Math.abs(kpi.change)}%
                  </Badge>
                </div>
                
                <div className="space-y-2">
                  <p className="text-sm font-medium text-muted-foreground">{kpi.title}</p>
                  <p className="text-3xl font-bold text-gray-900 dark:text-gray-100">{kpi.value}</p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="grid gap-8 lg:grid-cols-3">
          {/* Performance Chart */}
          <Card className="lg:col-span-2 border-0 bg-white/50 dark:bg-gray-900/50 backdrop-blur-xl rounded-3xl shadow-xl shadow-gray-500/10">
            <CardHeader className="pb-6">
              <CardTitle className="flex items-center gap-3 text-2xl">
                <div className="p-2 bg-gradient-to-br from-blue-500 to-purple-500 rounded-xl shadow-lg">
                  <BarChart3 className="w-6 h-6 text-white" />
                </div>
                Απόδοση ανά Πλατφόρμα
              </CardTitle>
              <CardDescription className="text-base">
                Κατανομή του budget και της απόδοσης
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                {PERFORMANCE_DATA.map((item, index) => (
                  <div key={index} className="flex items-center justify-between p-4 hover:bg-white/50 dark:hover:bg-gray-800/50 rounded-2xl transition-all duration-300 border border-transparent hover:border-gray-200/50 dark:hover:border-gray-700/50">
                    <div className="flex items-center gap-4">
                      <div className={`w-4 h-4 bg-gradient-to-r ${item.color} rounded-full shadow-sm`} />
                      <span className="font-medium text-gray-900 dark:text-gray-100">{item.name}</span>
                    </div>
                    <div className="flex items-center gap-4">
                      <div className="w-32 bg-gray-200 dark:bg-gray-700 rounded-full h-2">
                        <div 
                          className={`h-2 bg-gradient-to-r ${item.color} rounded-full transition-all duration-1000 ease-out`}
                          style={{ width: `${item.value}%` }}
                        />
                      </div>
                      <span className="font-semibold text-gray-900 dark:text-gray-100 w-12 text-right">{item.value}%</span>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Recent Activity */}
          <Card className="border-0 bg-white/50 dark:bg-gray-900/50 backdrop-blur-xl rounded-3xl shadow-xl shadow-gray-500/10">
            <CardHeader className="pb-6">
              <CardTitle className="flex items-center gap-3 text-2xl">
                <div className="p-2 bg-gradient-to-br from-green-500 to-emerald-500 rounded-xl shadow-lg">
                  <Zap className="w-6 h-6 text-white" />
                </div>
                Πρόσφατη Δραστηριότητα
              </CardTitle>
              <CardDescription className="text-base">
                Τελευταίες ενέργειες και αλλαγές
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {RECENT_ACTIVITY.map((activity, index) => (
                <div key={index} className="flex items-start gap-4 p-4 hover:bg-white/50 dark:hover:bg-gray-800/50 rounded-2xl transition-all duration-300 border border-transparent hover:border-gray-200/50 dark:hover:border-gray-700/50">
                  <div className="flex-shrink-0 w-2 h-2 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full mt-2" />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-gray-900 dark:text-gray-100 mb-1">
                      {activity.action}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      {activity.time}
                    </p>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>
        </div>

        {/* Quick Actions */}
        <Card className="border-0 bg-gradient-to-br from-blue-50/50 to-purple-50/50 dark:from-blue-950/20 dark:to-purple-950/20 backdrop-blur-xl rounded-3xl shadow-xl shadow-blue-500/10">
          <CardHeader className="text-center pb-8">
            <CardTitle className="flex items-center justify-center gap-3 text-2xl">
              <div className="p-3 bg-gradient-to-br from-blue-500 to-purple-500 rounded-2xl shadow-lg">
                <Sparkles className="w-6 h-6 text-white" />
              </div>
              Γρήγορες Ενέργειες
            </CardTitle>
            <CardDescription className="text-lg">
              Δημιουργήστε νέες καμπάνιες και δείτε αναφορές
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid gap-6 md:grid-cols-3">
              <Button 
                onClick={() => navigate('/campaigns')}
                className="group p-6 h-auto flex flex-col items-center gap-4 bg-white/50 dark:bg-gray-900/50 backdrop-blur-xl hover:bg-white/70 dark:hover:bg-gray-900/70 rounded-2xl border border-gray-200/50 dark:border-gray-700/50 transition-all duration-300 hover:scale-105"
              >
                <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-blue-600 rounded-2xl flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform duration-300">
                  <Target className="w-8 h-8 text-white" />
                </div>
                <div className="text-center">
                  <h4 className="font-semibold text-gray-900 dark:text-gray-100 mb-2">Νέα Καμπάνια</h4>
                  <p className="text-sm text-gray-600 dark:text-gray-300">Δημιουργήστε μια νέα καμπάνια</p>
                </div>
              </Button>
              
              <Button 
                onClick={() => navigate('/analytics')}
                className="group p-6 h-auto flex flex-col items-center gap-4 bg-white/50 dark:bg-gray-900/50 backdrop-blur-xl hover:bg-white/70 dark:hover:bg-gray-900/70 rounded-2xl border border-gray-200/50 dark:border-gray-700/50 transition-all duration-300 hover:scale-105"
              >
                <div className="w-16 h-16 bg-gradient-to-br from-purple-500 to-purple-600 rounded-2xl flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform duration-300">
                  <BarChart3 className="w-8 h-8 text-white" />
                </div>
                <div className="text-center">
                  <h4 className="font-semibold text-gray-900 dark:text-gray-100 mb-2">Analytics</h4>
                  <p className="text-sm text-gray-600 dark:text-gray-300">Δείτε λεπτομερείς αναλύσεις</p>
                </div>
              </Button>
              
              <Button 
                onClick={() => navigate('/funnel-analysis')}
                className="group p-6 h-auto flex flex-col items-center gap-4 bg-white/50 dark:bg-gray-900/50 backdrop-blur-xl hover:bg-white/70 dark:hover:bg-gray-900/70 rounded-2xl border border-gray-200/50 dark:border-gray-700/50 transition-all duration-300 hover:scale-105"
              >
                <div className="w-16 h-16 bg-gradient-to-br from-green-500 to-green-600 rounded-2xl flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform duration-300">
                  <TrendingUp className="w-8 h-8 text-white" />
                </div>
                <div className="text-center">
                  <h4 className="font-semibold text-gray-900 dark:text-gray-100 mb-2">Funnel Analysis</h4>
                  <p className="text-sm text-gray-600 dark:text-gray-300">Αναλύστε το customer journey</p>
                </div>
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
} 