import { AuthProvider, useAuth } from '@/lib/auth-context';
import { ThemeProvider } from "@/components/theme-provider";
import { LoginForm } from '@/components/login-form';
import { Navbar } from '@/components/navbar';
import { AppSidebar } from '@/components/appSidebar';
import { Settings } from '@/pages/Settings';
import { Dashboard } from '@/pages/Dashboard';
import Campaigns from '@/pages/Campaigns';
import { Analytics } from '@/pages/Analytics';
import { CampaignAnalysis } from '@/pages/CampaignAnalysis';
import { FunnelAnalysis } from '@/pages/FunnelAnalysis';
import { TestAuth } from '@/pages/TestAuth';
import { BrowserRouter as Router, Routes, Route, useNavigate, useLocation } from 'react-router-dom';
import {
  SidebarProvider,
  SidebarInset,
} from "@/components/ui/sidebar";
import { Loader2 } from "lucide-react";
import { useKeyboardShortcuts } from '@/hooks/use-keyboard-shortcuts';
import { useTheme } from 'next-themes';
import { toast } from 'sonner';
import { CommandPalette } from '@/components/command-palette';
import { useState, useEffect } from 'react';
import { KeyboardShortcutsHelp } from '@/components/keyboard-shortcuts-help';
import { NotificationsProvider } from '@/lib/notifications-context';
import { ErrorBoundaryWrapper } from '@/components/error-boundary';
import { PerformanceMonitor } from '@/components/performance-monitor';
import { OnboardingTour } from '@/components/onboarding-tour';
import { HelpCenterDialog } from '@/components/help-center';
import Home from '@/pages/Home';

function AppContent() {
  const { user, loading } = useAuth();
  const { setTheme, theme } = useTheme();
  const [showShortcuts, setShowShortcuts] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();

  const handleRefresh = () => {
    window.location.reload();
  };

  const handleExport = () => {
    toast.info('Export functionality coming soon!');
  };

  const handleToggleDemoMode = () => {
    const currentDemoMode = localStorage.getItem('demoMode') === 'true';
    const newDemoMode = !currentDemoMode;
    localStorage.setItem('demoMode', newDemoMode.toString());
    toast.success(`Demo mode ${newDemoMode ? 'enabled' : 'disabled'}`);
    window.location.reload();
  };

  const handleToggleTheme = () => {
    setTheme(theme === 'light' ? 'dark' : 'light');
  };

  // Initialize keyboard shortcuts
  useKeyboardShortcuts({
    onRefresh: handleRefresh,
    onExport: handleExport,
    onToggleDemoMode: handleToggleDemoMode,
    onToggleTheme: handleToggleTheme
  });

  // Redirect to /login if not authenticated and on a protected route
  useEffect(() => {
    if (!loading && !user) {
      const publicRoutes = ['/', '/login'];
      if (!publicRoutes.includes(location.pathname)) {
        navigate('/login', { replace: true });
      }
    }
  }, [user, loading, location.pathname, navigate]);

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="flex flex-col items-center gap-4">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
          <p className="text-muted-foreground">Loading Ads Pro...</p>
        </div>
      </div>
    );
  }

  return (
    <SidebarProvider>
      <CommandPalette 
        onToggleDemoMode={handleToggleDemoMode}
        onShowShortcuts={() => setShowShortcuts(true)}
      />
      {showShortcuts && <KeyboardShortcutsHelp />}
      <div className="flex flex-col w-full min-h-screen bg-background">
        <Navbar />
        {!user ? (
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/login" element={<LoginForm />} />
            <Route path="*" element={<Home />} />
          </Routes>
        ) : (
          <div className="flex flex-1">
            <AppSidebar />
            <SidebarInset className="flex-1">
              <main className="flex-1">
                <Routes>
                  <Route path="/" element={<Dashboard />} />
                  <Route path="/campaigns" element={<Campaigns />} />
                  <Route path="/analytics" element={<Analytics />} />
                  <Route path="/campaign-analysis" element={<CampaignAnalysis />} />
                  <Route path="/funnel-analysis" element={<FunnelAnalysis />} />
                  <Route path="/settings" element={<Settings />} />
                  <Route path="/test-auth" element={<TestAuth />} />
                  <Route path="*" element={
                    <div className="flex items-center justify-center min-h-[50vh]">
                      <div className="text-center space-y-4">
                        <h1 className="text-2xl font-bold">404 - Page Not Found</h1>
                        <p className="text-muted-foreground">The page you're looking for doesn't exist.</p>
                      </div>
                    </div>
                  } />
                </Routes>
              </main>
            </SidebarInset>
          </div>
        )}
      </div>
    </SidebarProvider>
  );
}

function App() {
  return (
    <AuthProvider>
      <ThemeProvider 
        attribute="class" 
        defaultTheme="system" 
        enableSystem
        disableTransitionOnChange
        storageKey="volo-app-theme"
      >
        <NotificationsProvider>
          <Router>
            <ErrorBoundaryWrapper>
              <PerformanceMonitor id="app" enabled={process.env.NODE_ENV === 'development'}>
                <AppContent />
                <OnboardingTour isFirstTime={true} />
                <HelpCenterDialog />
              </PerformanceMonitor>
            </ErrorBoundaryWrapper>
          </Router>
        </NotificationsProvider>
      </ThemeProvider>
    </AuthProvider>
  );
}

export default App;
